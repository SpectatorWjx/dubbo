package com.demo.api;

import com.demo.api.domain.User;

/**
 * 测试服务
 * @author ch
 *
 */
public interface DemoServices {
	
	User toProvider() throws Exception;

}
