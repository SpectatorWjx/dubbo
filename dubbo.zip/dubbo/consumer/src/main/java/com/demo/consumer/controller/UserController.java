package com.demo.consumer.controller;

import com.demo.api.domain.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.demo.consumer.service.DemoServiceCon;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class UserController
{

    @Autowired
    DemoServiceCon demoServiceCon;

    @RequestMapping("test")
    @ResponseBody
    public User index() throws Exception {
        return demoServiceCon.ConService();
    }

}
