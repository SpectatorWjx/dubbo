package com.demo.consumer.service;

import com.demo.api.domain.User;

/**
 * 消费服务
 * @author ch
 *
 */
public interface DemoServiceCon {
	
	public User ConService() throws Exception;

}
