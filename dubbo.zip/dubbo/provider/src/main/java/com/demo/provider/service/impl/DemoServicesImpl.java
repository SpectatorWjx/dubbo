package com.demo.provider.service.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.demo.api.DemoServices;
import com.demo.api.domain.User;

@Service(version = "1.0.0")
public class DemoServicesImpl implements DemoServices
{

    @Override
    public User toProvider() throws Exception {
        return new User();
    }

}
